#include <ArduinoBLE.h>

// Deklarace globálních proměnných před funkcí setup()
BLEService testService("12345678-1234-5678-1234-56789abcdef0"); 
BLECharacteristic randomCharacteristic("abcdef01-1234-5678-1234-56789abcdef0", BLERead | BLENotify, 4);

void setup() {
  Serial.begin(9600);
  
  // Inicializace BLE modulu
  if (!BLE.begin()) {
    Serial.println("Inicializace BLE selhala!");
    while (1); 
  }

  // Nastavení názvu zařízení
  BLE.setLocalName("MojeArduino");
  
  // Propojení služby a charakteristiky
  BLE.setAdvertisedService(testService);
  testService.addCharacteristic(randomCharacteristic);
  
  // Registrace služby do BLE stacku
  BLE.addService(testService);

  // Spuštění vysílání (advertising)
  BLE.advertise();
  Serial.println("BLE vysílá (advertising). Čekám na připojení klienta...");
}

void loop() {
  // Kontrola, zda se k Arduinu připojil BLE klient
  BLEDevice central = BLE.central();

  // Pokud ano...
  if (central) {
    // Na sériový port se vypíše jeho adresa
    Serial.print("Připojen klient s MAC adresou: ");
    Serial.println(central.address());

    // Po dobu připojení...
    while (central.connected()) {
      // ...se každou sekundu generuje náhodné číslo...
      int32_t randomNumber = random(1, 101); 
      
      // ...které se zapíše do charakteristiky...
      randomCharacteristic.writeValue((uint8_t*)&randomNumber, sizeof(randomNumber));
      
      // ...a současně se vypíše na sériový port.
      Serial.print("Odesláno: ");
      Serial.println(randomNumber);
      
      delay(1000); 
    }

    // Po odpojení klienta se vypíše hláška o ukončení spojení
    Serial.print("Klient odpojen. MAC: ");
    Serial.println(central.address());
  }
}