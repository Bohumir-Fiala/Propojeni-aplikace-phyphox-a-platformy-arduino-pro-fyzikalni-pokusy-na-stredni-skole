#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h> // Nutné pro notifikace ve Phyphoxu!

// Stejná UUID jako ve vašem Arduino kódu
#define SERVICE_UUID        "12345678-1234-5678-1234-56789abcdef0"
#define CHARACTERISTIC_UUID "abcdef01-1234-5678-1234-56789abcdef0"

BLEServer* pServer = NULL;
BLECharacteristic* pCharacteristic = NULL;
bool deviceConnected = false;
bool oldDeviceConnected = false;

// Třída pro sledování, zda se Phyphox připojil nebo odpojil
class MyServerCallbacks: public BLEServerCallbacks {
    void onConnect(BLEServer* pServer) {
      deviceConnected = true;
      Serial.println("Phyphox připojen!");
    };

    void onDisconnect(BLEServer* pServer) {
      deviceConnected = false;
      Serial.println("Phyphox odpojen!");
    }
};

void setup() {
  Serial.begin(9600);
  Serial.println("Startuji BLE server...");

  // 1. Inicializace zařízení a názvu
  BLEDevice::init("MojeArduino");

  // 2. Vytvoření serveru a nastavení callbacků (sledování připojení)
  pServer = BLEDevice::createServer();
  pServer->setCallbacks(new MyServerCallbacks());

  // 3. Vytvoření služby (Service)
  BLEService *pService = pServer->createService(SERVICE_UUID);

  // 4. Vytvoření charakteristiky s právy číst a notifikovat
  pCharacteristic = pService->createCharacteristic(
                      CHARACTERISTIC_UUID,
                      BLECharacteristic::PROPERTY_READ |
                      BLECharacteristic::PROPERTY_NOTIFY
                    );

  // 5. DŮLEŽITÉ PRO ESP32: Přidání deskriptoru pro notifikace
  pCharacteristic->addDescriptor(new BLE2902());

  // Spuštění služby
  pService->start();

  // Spuštění vysílání, aby nás mobil našel
  BLEAdvertising *pAdvertising = BLEDevice::getAdvertising();
  pAdvertising->addServiceUUID(SERVICE_UUID);
  pAdvertising->setScanResponse(true);
  pAdvertising->setMinPreferred(0x06); // Funkce pro lepší kompatibilitu s iPhony
  pAdvertising->setMinPreferred(0x12);
  BLEDevice::startAdvertising();
  
  Serial.println("BLE server běží, čekám na připojení...");
}

void loop() {
  // Pokud je Phyphox připojený, posíláme data
  if (deviceConnected) {
    // Vygeneruj náhodné číslo 1-100 (jako 32bitový integer)
    int32_t randomNumber = random(1, 101);

    // Na ESP32 musíme data posílat jako pole bajtů (ukazatel do paměti)
    pCharacteristic->setValue((uint8_t*)&randomNumber, 4);
    
    // Odeslání notifikace do mobilu
    pCharacteristic->notify(); 

    Serial.print("Odesláno: ");
    Serial.println(randomNumber);

    delay(1000); // Počkej 1 sekundu
  }

  // Obsluha odpojení: Pokud se mobil odpojí, ESP32 musí začít znovu vysílat
  if (!deviceConnected && oldDeviceConnected) {
      delay(500); 
      pServer->startAdvertising(); 
      Serial.println("Znovu spouštím vysílání BLE...");
      oldDeviceConnected = deviceConnected;
  }
  
  // Zaznamenání nového připojení
  if (deviceConnected && !oldDeviceConnected) {
      oldDeviceConnected = deviceConnected;
  }
}
