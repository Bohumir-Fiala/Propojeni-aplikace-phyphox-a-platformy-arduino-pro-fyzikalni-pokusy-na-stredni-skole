#include <Wire.h>
#include <Adafruit_Sensor.h>
#include <Adafruit_BMP280.h>
#include <phyphoxBle.h>

// --- Nastavení senzoru BMP280 ---
Adafruit_BMP280 bmp; // I2C

// Časování
unsigned long previousMillis = 0;
const long interval = 2000;

// Globální instance experimentu (musí být deklarována globálně, ne uvnitř setup)
PhyphoxBleExperiment experiment;

void setup() {
  Serial.begin(9600);

  // 1. Inicializace BMP280
  if (!bmp.begin(0x76)) {
    Serial.println("Chyba BMP280!");
    while (1);
  }
  bmp.setSampling(Adafruit_BMP280::MODE_NORMAL,
                  Adafruit_BMP280::SAMPLING_X2,
                  Adafruit_BMP280::SAMPLING_X16,
                  Adafruit_BMP280::FILTER_X16,
                  Adafruit_BMP280::STANDBY_MS_500);

  // 2. Start Phyphox BLE serveru
  PhyphoxBLE::start("Termo_Arduino"); 

  // 3. Vytvoření experimentu
  experiment.setTitle("Izochorický děj (PhyphoxBLE)");
  experiment.setCategory("BP");
  experiment.setDescription("Experiment generovaný přímo z Arduina.");

  // --- PRVNÍ OBRAZOVKA (Stabilní data) ---
  PhyphoxBleExperiment::View view1;
  view1.setLabel("Stabilní data");

  // Boxík pro teplotu
  PhyphoxBleExperiment::Value valTemp;
  valTemp.setLabel("Teplota"); valTemp.setUnit("°C"); 
  valTemp.setChannel(1); 
  view1.addElement(valTemp);

  // Boxík pro teplotu v Kelvinech
  PhyphoxBleExperiment::Value valTempK;
  valTempK.setLabel("Teplota (abs)"); valTempK.setUnit("K"); 
  valTempK.setChannel(3); 
  view1.addElement(valTempK);

  // Boxík pro tlak
  PhyphoxBleExperiment::Value valPress;
  valPress.setLabel("Tlak"); valPress.setUnit("hPa"); 
  valPress.setChannel(2);
  view1.addElement(valPress);

  //Hodnota konstanty p-T
  PhyphoxBleExperiment::Value valConst;
  valConst.setLabel("Konstanta p/T"); valConst.setUnit("hPa/K");
  valConst.setChannel(4); // Konstanta je čtvrtá proměnná ve funkci write()
  view1.addElement(valConst);

  // Graf závislosti p-T
  PhyphoxBleExperiment::Graph graphPT;
  graphPT.setLabel("Závislost Tlaku na Teplotě");
  graphPT.setLabelX("Teplota [°C]"); graphPT.setLabelY("Tlak [hPa]");
  graphPT.setChannel(1, 2); 
  view1.addElement(graphPT);

  experiment.addView(view1); 

  // --- DRUHÁ OBRAZOVKA (Časový vývoj) ---
  PhyphoxBleExperiment::View view2;
  view2.setLabel("Časový vývoj");

  PhyphoxBleExperiment::Graph graphTimeT;
  graphTimeT.setLabel("Teplota v čase");
  graphTimeT.setLabelX("Čas [s]"); graphTimeT.setLabelY("Teplota [°C]");
  graphTimeT.setChannel(0, 1); 
  view2.addElement(graphTimeT);

  PhyphoxBleExperiment::Graph graphTimeP;
  graphTimeP.setLabel("Tlak v čase");
  graphTimeP.setLabelX("Čas [s]"); graphTimeP.setLabelY("Tlak [hPa]");
  graphTimeP.setChannel(0, 2); 
  view2.addElement(graphTimeP);

  experiment.addView(view2);

  // 4. Předání hotového experimentu knihovně
  PhyphoxBLE::addExperiment(experiment);
}

void loop() {
  // TENTO PŘÍKAZ JE PRO UNO R4 WIFI KRITICKÝ!
  // Odbavuje požadavky telefonu a stará se o odeslání XML experimentu
PhyphoxBLE::poll(); 

  unsigned long currentMillis = millis();

  if (currentMillis - previousMillis >= interval) {
    previousMillis = currentMillis;

    // A. Měření ze senzoru
    float t = bmp.readTemperature();
    float p = bmp.readPressure() / 100.0F; 

    // B. Matematika
    float tK = t + 273.15;
    float konstanta = p / tK;

    // C. Odeslání dat
    PhyphoxBLE::write(t, p, tK, konstanta); 
  }
}
