#include <Wire.h>
#include <Adafruit_Sensor.h>
#include <Adafruit_BMP280.h>
#include <ArduinoBLE.h>

// --- Nastavení senzoru BMP280 ---
Adafruit_BMP280 bmp; // I2C

// --- Nastavení BLE ---
// Generujeme UUID
BLEService thermoService("12345678-1234-5678-1234-56789abcdef1"); 

// Charakteristika bude posílat 8 bajtů (2x float po 4 bajtech)
BLECharacteristic dataCharacteristic("abcdef01-1234-5678-1234-56789abcdef1", 
                                     BLERead | BLENotify, 8); 

// Struktura pro zabalení dat (aby šly poslat najednou)
struct DataPacket {
  float teplota;
  float tlak;
};

DataPacket packet; // Instance balíčku dat

// Časování
unsigned long previousMillis = 0;
const long interval = 2000;

void setup() {
  Serial.begin(9600);
  // while (!Serial); // Odkomentovat jen pro ladění, jinak se program bez PC nespustí!

  // 1. Inicializace BMP280
  if (!bmp.begin(0x76)) { // Zkuste 0x76 nebo 0x77, některé senzory mohou využívat odlišné
    Serial.println("Chyba BMP280! Zkontrolujte zapojení.");
    while (1);
  }

  // Nastavení pro stabilní měření (filtrujeme šum)
  bmp.setSampling(Adafruit_BMP280::MODE_NORMAL,
                  Adafruit_BMP280::SAMPLING_X2,  // Teplota
                  Adafruit_BMP280::SAMPLING_X16, // Tlak (vysoký oversampling)
                  Adafruit_BMP280::FILTER_X16,   // Filtrace
                  Adafruit_BMP280::STANDBY_MS_500);

  // 2. Inicializace BLE
  if (!BLE.begin()) {
    Serial.println("Chyba startu BLE!");
    while (1);
  }

  BLE.setLocalName("Moje_Arduino_2");
  BLE.setAdvertisedService(thermoService);
  
  thermoService.addCharacteristic(dataCharacteristic);
  BLE.addService(thermoService);
  
  BLE.advertise();
  Serial.println("BLE běží. Čekám na Phyphox...");
}

void loop() {
  BLE.poll(); // Udržuje BLE naživu

  unsigned long currentMillis = millis();

  if (currentMillis - previousMillis >= interval) {
    previousMillis = currentMillis;

    // A. Měření
    float t = bmp.readTemperature();
    float p = bmp.readPressure() / 100.0F; // Převod Pa -> hPa

    // B. Uložení do struktury
    packet.teplota = t;
    packet.tlak = p;

    // C. Výpis pro kontrolu (Sériová linka)
    Serial.print("T: "); Serial.print(t);
    Serial.print(" C, P: "); Serial.print(p);
    Serial.println(" hPa");

    // D. Odeslání přes BLE (pokud je někdo připojen)
    // Odesíláme celou strukturu jako blok bajtů
    if (BLE.central() && BLE.central().connected()) {
       dataCharacteristic.writeValue((uint8_t*)&packet, sizeof(packet));
    }
  }
}