#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>
#include <Wire.h>
#include <Adafruit_Sensor.h>
#include <Adafruit_BMP280.h>

#define SERVICE_UUID        "12345678-1234-5678-1234-56789abcdef1"
#define CHARACTERISTIC_UUID "abcdef01-1234-5678-1234-56789abcdef1"

BLEServer* pServer = NULL;
BLECharacteristic* pCharacteristic = NULL;
bool deviceConnected = false;
bool oldDeviceConnected = false;

Adafruit_BMP280 bmp; // Objekt senzoru

// --- Struktura pro zabalení dat ---
struct DataPacket {
  float teplota;
  float tlak;
};
DataPacket packet; // Instance balíčku dat

// Časování
unsigned long previousMillis = 0;
const long interval = 2000;

class MyServerCallbacks: public BLEServerCallbacks {
    void onConnect(BLEServer* pServer) {
      deviceConnected = true;
      Serial.println("Phyphox pripojen!");
    };
    void onDisconnect(BLEServer* pServer) {
      deviceConnected = false;
      Serial.println("Phyphox odpojen!");
    }
};

void setup() {
  Serial.begin(9600);
  Serial.println("Startuji ESP32...");

  // 1. Inicializace BMP280
  if (!bmp.begin(0x76)) { // Pokud hází chybu, zkuste 0x77
    Serial.println("Chyba BMP280! Zkontrolujte zapojeni.");
    while (1);
  }

  // 2. Nastavení pro stabilní měření (výrazně sníží šum v datech!)
  bmp.setSampling(Adafruit_BMP280::MODE_NORMAL,
                  Adafruit_BMP280::SAMPLING_X2,  // Teplota
                  Adafruit_BMP280::SAMPLING_X16, // Tlak (vysoký oversampling)
                  Adafruit_BMP280::FILTER_X16,   // Filtrace
                  Adafruit_BMP280::STANDBY_MS_500);

  // 3. Inicializace BLE
  BLEDevice::init("Moje_Arduino_2");
  pServer = BLEDevice::createServer();
  pServer->setCallbacks(new MyServerCallbacks());
  
  BLEService *pService = pServer->createService(SERVICE_UUID);
  pCharacteristic = pService->createCharacteristic(
                      CHARACTERISTIC_UUID,
                      BLECharacteristic::PROPERTY_READ |
                      BLECharacteristic::PROPERTY_NOTIFY
                    );
                    
  pCharacteristic->addDescriptor(new BLE2902());
  pService->start();

  BLEAdvertising *pAdvertising = BLEDevice::getAdvertising();
  pAdvertising->addServiceUUID(SERVICE_UUID);
  pAdvertising->setScanResponse(true);
  pAdvertising->setMinPreferred(0x06);  
  pAdvertising->setMinPreferred(0x12);
  BLEDevice::startAdvertising();
  
  Serial.println("BLE bezi. Cekam na Phyphox...");
}

void loop() {
  // Odesílání probíhá jen, když je mobil připojen
  if (deviceConnected) {
    unsigned long currentMillis = millis();

    // Časování každých 500 ms (2x za vteřinu)
    if (currentMillis - previousMillis >= interval) {
      previousMillis = currentMillis;

      // A. Měření a uložení rovnou do struktury
      packet.teplota = bmp.readTemperature();
      packet.tlak = bmp.readPressure() / 100.0F;

      // B. Výpis pro kontrolu
      Serial.print("T: "); Serial.print(packet.teplota);
      Serial.print(" C, P: "); Serial.print(packet.tlak);
      Serial.println(" hPa");

      // C. Odeslání stejným způsobem jako na Arduinu
      pCharacteristic->setValue((uint8_t*)&packet, sizeof(packet));
      pCharacteristic->notify();
    }
  }

  // Obsluha odpojení (znovu zapne vysílání, aby šlo znovu připojit)
  if (!deviceConnected && oldDeviceConnected) {
      delay(500); 
      pServer->startAdvertising(); 
      Serial.println("Znovu spoustim vysilani...");
      oldDeviceConnected = deviceConnected;
  }
  if (deviceConnected && !oldDeviceConnected) {
      oldDeviceConnected = deviceConnected;
  }
}