#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>

// --- HC-SR04 piny ---
const int trigPin = 5;  // GPIO 5
const int echoPin = 18; // GPIO 18

// --- BLE nastavení (stejná UUID jako u Arduina) ---
#define SERVICE_UUID        "12345678-1234-5678-1234-56789abcdef0"
#define CHARACTERISTIC_UUID "abcdef01-1234-5678-1234-56789abcdef0"

BLEServer* pServer = NULL;
BLECharacteristic* pCharacteristic = NULL;
bool deviceConnected = false;
bool oldDeviceConnected = false;

// Třída pro detekci připojení/odpojení Phyphoxu
class MyServerCallbacks: public BLEServerCallbacks {
    void onConnect(BLEServer* pServer) {
      deviceConnected = true;
      Serial.println("Phyphox pripojen!");
    };

    void onDisconnect(BLEServer* pServer) {
      deviceConnected = false;
      Serial.println("Phyphox odpojen!");
    }
};

void setup() {
  Serial.begin(9600);
  pinMode(trigPin, OUTPUT);
  pinMode(echoPin, INPUT);

  Serial.println("Spoustim BLE server...");

  // Inicializace BLE na ESP32
  BLEDevice::init("MojeESP32"); // Název, který uvidíte ve Phyphoxu
  pServer = BLEDevice::createServer();
  pServer->setCallbacks(new MyServerCallbacks());

  BLEService *pService = pServer->createService(SERVICE_UUID);

  // Vytvoření charakteristiky s právy pro čtení a notifikaci
  pCharacteristic = pService->createCharacteristic(
                      CHARACTERISTIC_UUID,
                      BLECharacteristic::PROPERTY_READ   |
                      BLECharacteristic::PROPERTY_NOTIFY
                    );

  // Přidání deskriptoru 2902 je nutné pro fungování notifikací na ESP32
  pCharacteristic->addDescriptor(new BLE2902());

  pService->start();

  // Spuštění viditelnosti (advertising)
  BLEAdvertising *pAdvertising = BLEDevice::getAdvertising();
  pAdvertising->addServiceUUID(SERVICE_UUID);
  pAdvertising->setScanResponse(true);
  pAdvertising->setMinPreferred(0x06);  // Pomáhá s připojením na iPhonech
  pAdvertising->setMinPreferred(0x12);
  BLEDevice::startAdvertising();
  
  Serial.println("BLE server bezi, cekam na pripojeni...");
}

void loop() {
  // --- Řešení znovupřipojení po odpojení (nutné u ESP32) ---
  if (!deviceConnected && oldDeviceConnected) {
      delay(500); // Chvíli počkáme
      pServer->startAdvertising(); // Znovu začneme vysílat
      Serial.println("Znovu vysilam Bluetooth signal...");
      oldDeviceConnected = deviceConnected;
  }
  if (deviceConnected && !oldDeviceConnected) {
      oldDeviceConnected = deviceConnected;
  }

  // --- Měření probíhá vždy ---
  long duration;
  long cm;

  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);

  duration = pulseIn(echoPin, HIGH, 30000UL); // timeout 30 ms ≈ 5 m

  if (duration > 0) {
    cm = duration / 29 / 2;
    float m = cm / 100.0;   // převod na metry (float)

    // Výpis na sériový monitor
    Serial.print("Vzdalenost: ");
    Serial.print(cm);
    Serial.print(" cm  (");
    Serial.print(m, 2);
    Serial.println(" m)");

    // Pokud je připojen Phyphox (klient), pošleme data přes BLE
    if (deviceConnected) {
      // U ESP32 se data odesílají takto. 
      // (uint8_t*)&m vezme náš float a rozloží ho na 4 bajty.
      pCharacteristic->setValue((uint8_t*)&m, 4);
      pCharacteristic->notify(); // Odeslání notifikace
    }
  } else {
    Serial.println("Zadna odezva ze senzoru");
  }

  delay(100);
}


