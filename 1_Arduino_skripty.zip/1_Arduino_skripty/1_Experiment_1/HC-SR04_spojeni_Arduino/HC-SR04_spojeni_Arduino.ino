#include <ArduinoBLE.h>

// --- HC-SR04 piny ---
const int trigPin = 7;
const int echoPin = 8;

// --- BLE nastavení ---
BLEService myService("12345678-1234-5678-1234-56789abcdef0");
BLECharacteristic myCharacteristic("abcdef01-1234-5678-1234-56789abcdef0",
                                   BLERead | BLENotify, 4); // 4 bajty pro float

void setup() {
  Serial.begin(9600);
  while (!Serial);

  pinMode(trigPin, OUTPUT);
  pinMode(echoPin, INPUT);

  if (!BLE.begin()) {
    Serial.println("BLE modul se nespustil!");
    while (1);
  }

  BLE.setLocalName("MojeArduino");
  BLE.setAdvertisedService(myService);
  myService.addCharacteristic(myCharacteristic);
  BLE.addService(myService);
  BLE.advertise();

  Serial.println("BLE server běží, čekám na připojení...");
}

void loop() {
  // Obsluha BLE událostí
  BLEDevice central = BLE.central();

  // --- Měření probíhá vždy ---
  long duration;
  long cm;

  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);

  duration = pulseIn(echoPin, HIGH, 30000UL); // timeout 30 ms ≈ 5 m

  if (duration > 0) {
    cm = duration / 29 / 2;
    float m = cm / 100.0;   // převod na metry

    // Výpis na sériový monitor (vždy)
    Serial.print("Vzdálenost: ");
    Serial.print(cm);
    Serial.print(" cm  (");
    Serial.print(m, 2);     // dvě desetinná místa
    Serial.println(" m)");

    // Pokud je připojen BLE klient, pošli metry
    if (central && central.connected()) {
      myCharacteristic.writeValue((uint8_t*)&m, sizeof(m));

    }
  } else {
    Serial.println("Žádná odezva");
  }

  delay(100);
}


